//Create a variable for your favorite fruit and print it.
let favouriteFruite : string = "Mango";
console.log("My favourite fruit is: " + favouriteFruite);

/*Write a function that
 takes a number and prints double its value. */
function printDoubleValue(num: number): void {
    console.log("Double the value is: " + (num * 2));
}
printDoubleValue(5);

/* Define a class called Person 
with a method sayHello that prints a greeting */
class Person {
    sayHello() : void {
        console.log("Hello! Welcome to TypeScript.");
    }
}
let person = new Person();
person.sayHello();