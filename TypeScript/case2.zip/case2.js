//Create a variable for your favorite fruit and print it.
var favouriteFruite = "Mango";
console.log("My favourite fruit is: " + favouriteFruite);
/*Write a function that
 takes a number and prints double its value. */
function printDoubleValue(num) {
    console.log("Double the value is: " + (num * 2));
}
printDoubleValue(5);
/* Define a class called Person
with a method sayHello that prints a greeting */
var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.sayHello = function () {
        console.log("Hello! Welcome to TypeScript.");
    };
    return Person;
}());
var person = new Person();
person.sayHello();
