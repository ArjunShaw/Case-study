//CAse1  Print your own name
let message : string = "Arjun Shaw";
console.log(`Hello, ${message}!`);

// Print your own age
let age : number = 25;
console.log(`I am ${age} years old.`);

// To assign a number value declared as string variable
let message1 : string = "Hello, World!";
// message1 = 20; // This will cause a TypeScript error
console.log(message1);






