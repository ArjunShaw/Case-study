//CAse1  Print your own name
var message = "Arjun Shaw";
console.log("Hello, ".concat(message, "!"));
// Print your own age
var age = 25;
console.log("I am ".concat(age, " years old."));
