export interface Course{
    id :string;
    name : string;
    capacity : number;
    students : string[];
}