export default interface ArtInterface {
  name: string;
  email: string;
  artProjects: string[];
  portfolioLink: string;
}
