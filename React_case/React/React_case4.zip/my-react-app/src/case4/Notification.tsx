import { useState } from "react";
import useNotifyStore from "./store/NotifyStore";
export default function NoficationList() {
  const notifications =
    useNotifyStore((state) => state.Notifications);
 const AddNotification=useNotifyStore((state)=>state.addnotification)
 const markasread=useNotifyStore((state)=>state.marksAsread)
 const [msg,setmsg]=useState<string>("")
 console.log(notifications)
 function handleAddNotification(msg:string){
     AddNotification(msg)
 }
  return <>
   <div>
      <input type="text" placeholder="write some message" onChange={(e)=>(setmsg(e.target.value))} />
      <br />
      <br />
      <button onClick={()=>{handleAddNotification(msg)}}>AddNotification</button>

      <div>
        <h1>Notifications</h1>
        {
           notifications.length>0 &&
           notifications.map(
             (data)=>(
              !data.read?
              <div style={{display:"flex", gap:"30px", background:"white" ,color:"#222"}}>
                <p style={{fontSize:"20px"}}>{data.message}</p>
                <button style={{width:"80px"}} onClick={()=>{markasread(data.id)}}>mark as read</button>
              </div>:""
             )
           )
        }
      </div>
   </div>
  </>;
}
