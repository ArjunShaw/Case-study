import { create } from "Zustand";
interface Notification {
  id: string;
  message: string;
  type: "info" | "error" | "Success";
  read: boolean;
}

interface NotificationStore {
  Notifications: Notification[];
  addnotification: (message: string) => void;
  marksAsread: (id: string) => void;
  clearNotification:(id:string)=>void;
}


const useNotifyStore = create<NotificationStore>((set) => ({
 Notifications:[],

 addnotification: (message) => set((state) => ({
      Notifications: [...state.Notifications, { id: Date.now().toString(), message, type:"info", read: false }],
    }))

 
    
,
 marksAsread:(id)=>{
    set((state)=>({
      Notifications:state.Notifications.map((notification)=>notification.id==id?{...notification,read:true}:notification)
    }))
 },

 clearNotification:(id)=>{
    set((state)=>({
        Notifications:state.Notifications.filter((notification)=>notification.id!=id)
    }))
 }
 
}));

export default useNotifyStore