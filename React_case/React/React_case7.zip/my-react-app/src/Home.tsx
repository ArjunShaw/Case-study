import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

export function Home() {
  const navigate = useNavigate();
  const [obj, setObj] = useState({
    DoctorId: "",
    patientId: "",
  });
  function handleSubmit() {
    navigate(`/Doctor/${obj.DoctorId}/patient/${obj.patientId}`);
  }
  return (
    <>
      <h1>View your appoitment</h1>
      <div>
        <input
          type="text"
          placeholder="Input the DoctorId"
          onChange={(e) => setObj({ ...obj, DoctorId: e.target.value })}
        />
        <br />
        <input
          type="text"
          placeholder="Input the patientId"
          onChange={(e) => setObj({ ...obj, patientId: e.target.value })}
        />
        <br />
        <button onClick={handleSubmit}>submit</button>
        <Link to={"/profilesetting"}>
          <button>setting</button>
        </Link>
          <Link to={"/Adminpanel"}>
          <button>Go to Admin</button>
        </Link>
      </div>
    </>
  );
}
