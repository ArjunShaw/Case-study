import { useQuery } from "@tanstack/react-query";
import { fetchCollaborators } from "./collaborator";
import { useCollaboratorStore } from "./collaboratorstore";

export const useCollaborators = () => {
  const setCollaborators = useCollaboratorStore(
    (state) => state.setCollaborators
  );

  return useQuery({
    queryKey: ["collaborators"],
    queryFn: fetchCollaborators,
    onSuccess: (data) => {
      // Sync React Query data into Zustand
      setCollaborators(data);
    },
  });
};
