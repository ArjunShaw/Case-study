import { useCollaborators } from "./useCollaborator";
import { useCollaboratorStore } from "./collaboratorstore";

const Collaborators = () => {
  const { isLoading, error } = useCollaborators();
  const collaborators = useCollaboratorStore(
    (state) => state.collaborators
  );

  if (isLoading) return <p>Loading...</p>;
  if (error instanceof Error) return <p>{error.message}</p>;

  return (
    <ul>
      {collaborators.map((c) => (
        <li key={c.id}>
          <strong>{c.name}</strong> – {c.email}
        </li>
      ))}
    </ul>
  );
};

export default Collaborators;
