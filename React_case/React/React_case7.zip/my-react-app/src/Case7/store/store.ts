import { create } from "Zustand";
import { devtools, persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";
//case 1 using persist that simply stores value in localstorage or sessional storage and migrate means adding new field or changing values
// export type User={
//      userId:string
//      token:string|null
//      expiredAt:number|null,
//      setUser:(id:string,token:string,exp:number)=>void,
//      role:"user"|"admin"
// }
// type persistedState={
//      userId:string
//      token:string|null
//      expiredAt:number|null,
//      role?:"user"|"admin"
// }
// const userStore=create<User>()(persist(
//      (set)=>({
//         userId:"",
//         token:null,
//         expiredAt:null,
//         role:"user",
//         setUser:(id,token,exp)=>{
//             set((state)=>({...state,userId:id,token:token,expiredAt:exp}))
//         }
//       }),
//      {
//         name:"app-storage",
//         partialize:(state)=>({
//             userId:state.userId,
//             token:state.token
//         }),
//         version:2,
//        migrate:(state:persistedState,version):persistedState=>{
//               if(version<2){
//                 return {...state,role:"admin"}
//               }
//               return state
//         }
//      }
// ))
// export default userStore

type Note={
noteId:string,
action:string,
timestamp:number,
}

interface Notes{
     notes:Note[],
     addHistoryEntry:(noteId:string,action:string)=>void
     clearHistory:(noteId:string)=>void
}

const NoteStore=create<Notes>()(
    devtools(
       persist(
          immer(
            (set)=>({
               notes:[],
               addHistoryEntry:(noteId,action)=>{
                    let obj={
                        noteId,
                        action,
                        timestamp:Number(Date.now().toString)
                    }
                    console.log(obj)
                    set((state)=>{
                        state.notes.push(obj);
                    })
                },
                clearHistory:(noteId)=>{
                    let obj;
                   set((state)=>{
                    obj=state.notes.find((note)=>note.noteId==noteId)
                    state.notes=state.notes.filter((note)=>note.noteId!=noteId)
                   })
                   console.log(obj)
                }
            })
          ),{
             name:"app-storage",
             partialize:(state)=>(
                {
                    notes:state.notes
                }
             )
          }
       ) 
    )
)
export default NoteStore
