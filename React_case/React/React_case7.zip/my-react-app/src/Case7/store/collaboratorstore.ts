import { create } from "Zustand";

export type Collaborator = {
  id: number;
  name: string;
  email: string;
};

type CollaboratorStore = {
  collaborators: Collaborator[];
  setCollaborators: (data: Collaborator[]) => void;
};

export const useCollaboratorStore = create<CollaboratorStore>((set) => ({
  collaborators: [],
  setCollaborators: (data) => set({ collaborators: data }),
}));
