import { useState } from "react"
import NoteStore from "./store"
export default function Zustand(){
    const [obj,setObj]=useState({
        NoteId:"",
        action:"",
    })
    const setUser=NoteStore((state)=>(state.addHistoryEntry))
    const addHistoryEntry=NoteStore((state)=>state.addHistoryEntry)
    const clearHistory=NoteStore((state)=>state.clearHistory)
    return(
        <>
         <div style={{display:"flex",flexDirection:"column",gap:"20px"}}>
            <input type="text" placeholder="NoteId" onChange={(e)=>(setObj({...obj,NoteId:e.target.value}))} />
            <input type="text" placeholder="token"  onChange={(e)=>(setObj({...obj,action:e.target.value}))}/>
            {/* <input type="text" placeholder="expiredAt"  onChange={(e)=>(setObj({...obj,expiredAt:Number(e.target.value)}))} /> */}
              <button onClick={()=>{
                addHistoryEntry(obj.NoteId,obj.action)
              }}>submit</button>

               <button onClick={()=>{
                clearHistory(obj.NoteId)
              }}>clear</button>


         </div>
        </>
    )
}