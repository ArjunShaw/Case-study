import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Parent from "../Parent";

import { Component } from "../case5/Component";
import Zustand from "./store/Zustand";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      
    
      <Zustand/>
    </>
    
  );
}

export default App;
