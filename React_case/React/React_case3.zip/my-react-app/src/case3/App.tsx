import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";


import { DoctorPatientDetails } from "./DoctorPatientDetails";
import { Route, Routes } from "react-router-dom";


function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      
      {/* <BudgetTracker /> */}


     <Suspense>
     <Routes>
        <Route path="/Doctor/:DoctorId/patient/:patientId" element={<DoctorPatientDetails />}></Route>
      

      </Routes>
   </Suspense>

      {/* <NoficationList/> */}
      {/* <Component/> */}
      {/* <Zustand/> */}
      {/* <ParentTag/> */}
    </>
    
  );
}

export default App;
