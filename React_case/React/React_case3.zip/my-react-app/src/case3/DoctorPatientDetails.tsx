import { Link, useParams } from "react-router-dom";
import DoctorPatient from "./data/DoctorPatient.json";
type DoctorPatientParams = {
  patientId: string;
  DoctorId: string;
};
export function DoctorPatientDetails() {
  const { patientId, DoctorId } = useParams<DoctorPatientParams>();
  console.log(patientId, DoctorId);
  return (
    <>
      <Link to={`/Doctor/${DoctorId}/patient/${patientId}`}>
        {DoctorPatient.map((data) =>
         ( patientId == data.patientId && DoctorId == data.doctorId) ? (
            <div>
              <h1>Doctor Details</h1>
              <div>
                <p>Doctor name:{data.doctor.name}</p>
                <p>Docotor Specalization:{data.doctor.specialization}</p>
              </div>
              <h1>Patient Details</h1>
              <div>
                <p>Patient name:{data.patient.name}</p>
                <p>patient age:{data.patient.age}</p>
                <p>patient medicalHistory:{data.patient.medicalHistory[0]}</p>
              </div>
            </div>
          ) : (
          <p>NO valid Information was found</p>
          )
        )}
      </Link>
    </>
  );
}
