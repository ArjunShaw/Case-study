import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";

import ParentTag from "../case8/parent1";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      

      <ParentTag/>
    </>
    
  );
}

export default App;
