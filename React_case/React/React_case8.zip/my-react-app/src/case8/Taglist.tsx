import React, { useEffect, useState } from "react";
import { useMemo } from "react";
type TagProps = {
  tags: string[];
  filter: string;
};
const Taglist = React.memo(({ tags, filter }: TagProps) => {
    console.log(tags)
const [filters,setFilters]=useState<string[]>([])
// const filtered=useMemo(()=>tags.filter(t=>t.includes(filter)),[tags,filter])
useEffect(()=>{
 if(filter==='')
    return;
 setFilters((prev)=>tags.filter((t)=>t.includes(filter)))
},[filter])

console.log(filters)
  return (
    <>
     <div>
        {
            filters.map((val)=>(
                <p>{val}</p>
            ))
        }
     </div>
    </>
  );
});
export default Taglist;
