import { useCallback, useState } from "react";
import Taglist from "./Taglist";

function ParentTag() {
  const [filter, setFilter] = useState("");
  const [tagVal, setTagVal] = useState<string>('');
  const [show ,setShow]=useState(false)
  const [tags, setTags] = useState<string[]>([
    "React",
    "JavaScript",
    "TypeScript",
    "Node",
    "Express",
    "MongoDB",
    "Zustand",
    "React Query",
  ]);
 const addTag=useCallback(()=>{ 
    if(!tagVal.trim()) return;
    setTags((prev)=>([...prev,tagVal.trim()]))}
    ,[tagVal])
  return (
    <div>
      <h2>Add a new Tag</h2>
    <input type="text" placeholder="Add a new Tag" onChange={(e)=>(setTagVal(e.target.value))} />
    <button onClick={addTag}>Add the tag</button>
      <h2>Tag Filter</h2>

      <input
        type="text"
        placeholder="Filter tags..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
      />
     <button onClick={()=>(setShow(true))}>click</button>
      {<Taglist tags={tags} filter={filter} />}
    </div>
  );
}

export default ParentTag;
