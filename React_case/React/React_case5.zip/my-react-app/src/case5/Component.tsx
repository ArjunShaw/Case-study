import { useState } from "react"

export function Component(){
    const [val,setval]=useState('')
    function onPost(){
       console.log('')
       setval('')
    }
    return <>
    <div>
        <input type="text" value={val} onChange={(e)=>{setval(e.target.value)}} />
        <button onClick={onPost}>Post</button>
    </div>
    </>
}