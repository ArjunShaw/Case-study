export default function Profiilesettings(){
    return (
        <>
        <h1>ProfileSettings</h1>
        </>
    )
}