export default function Admin(){
    // throw new Error("App Creashed") for using Errorboundary
    return(
        <>
        <h1>Admin panel</h1>
        </>
    )
}