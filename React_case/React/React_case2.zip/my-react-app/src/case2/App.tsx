import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import BudgetTracker from "./BudgetTrackar";
function App() {

  return (
    <>
      <BudgetTracker/>
    </>
    
  );
}

export default App;
