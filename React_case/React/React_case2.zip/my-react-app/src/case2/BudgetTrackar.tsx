import React, { useEffect, useReducer, useState } from "react";

interface IncomeEntry {
  amount: number;
  currencies: "USD" | "INR";
}

interface ExpenseEntry {
  amount: number;
  currencies: "USD" | "INR";
}

type TransactionActon =
  | { type: "Add_income"; payload: IncomeEntry }
  | {
      type: "Add_expense";
      payload: ExpenseEntry;
    };

type Transaction = IncomeEntry | ExpenseEntry;

type BudgetTracker = {
  incomes: IncomeEntry[];
  expenses: ExpenseEntry[];
};

export default function BudgetTracker() {
  const reducer = (
    state: BudgetTracker,
    action: TransactionActon
  ): BudgetTracker => {
    switch (action.type) {
      case "Add_income":
        return { ...state, incomes: [...state.incomes, action.payload] };
      case "Add_expense":
        // let balance = NetBalance(state);
        // if (balance < 0) return state;
        return { ...state, expenses: [...state.expenses, action.payload] };
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, { incomes: [], expenses: [] });

  function NetBalance() {
    let totalIncome = 0;
    let totalExpense = 0;
    for (let income of state.incomes) {
      totalIncome += income.amount;
    }

    for (let expense of state.expenses) {
      totalExpense += expense.amount;
    }
    if (totalIncome - totalExpense) setBalance(totalIncome - totalExpense);
    return totalIncome - totalExpense;
  }

  const [balance, setBalance] = useState<number>(0);

  useEffect(() => {
    NetBalance();
  }, [state.incomes, state.expenses]);

  function addIncome(payload: IncomeEntry) {
    dispatch({ type: "Add_income", payload: payload });
  }

  function addExpense(payload: ExpenseEntry) {
    dispatch({ type: "Add_expense", payload: payload });
  }
  return (
    <div style={{ display: "flex", gap: "20px", flexDirection: "column" }}>
      <div style={{ display: "flex", gap: "10px", width: "300px" }}>
        <label htmlFor="currency_type">Input currency </label>
        <input
          id="currency_type"
          name="currency"
          placeholder="either USD or INR"
        ></input>
      </div>
      <div style={{ display: "flex", gap: "10px", width: "300px" }}>
        <label htmlFor="currency_value"> amount</label>
        <input
          id="currency_value"
          name="amount"
          placeholder="either USD or INR"
        ></input>
      </div>

      <button
        onClick={() => {
          addIncome({ amount: 2000, currencies: "USD" });
        }}
      >
        Add Income
      </button>
      <button onClick={() => addExpense({ amount: 200, currencies: "USD" })}>
        Add_expense
      </button>
      <h2>Total Balance:{balance}</h2>
    </div>
  );
}
